const Index = () => {
    return(
    <div>
        <h1>MEOW is here for you ❤️</h1>
    </div>
    );
};

export default Index;
const Koa = require('koa');
const next = require('next');
const Router = require('koa-router');
const fs = require('fs');

const dev = process.env.NODE_ENV !== 'production';
const app = next({dev: dev});
const handle = app.getRequestHandler();

app.prepare().then(() => {
    const server = new Koa();
    const router = new Router();
    var headers = ""
    var faq = ""
    fs.readFile('test.json', function(err, data) {
        var fulldata = JSON.parse(data)
        headers = fulldata.headers
        faq = fulldata.faq
    });
    const handleRequest = async (ctx) => {
        await handle(ctx.req, ctx.res);
        ctx.respond = false;
        ctx.res.statusCode = 200;
    };

    // headers
    router.get("/headers", ctx => {
        ctx.body = JSON.stringify(headers, null, 4)
    })
    // faq
    router.get("/faq", async (ctx) => {
        ctx.body = JSON.stringify(faq, null, 4)
    })

    router.get("(/_next/static/.*)", handleRequest);
    router.get("/_next/webpack-hmr", handleRequest);
    router.get("(.*)", handleRequest);

    server.use(router.allowedMethods());
    server.use(router.routes());

    server.listen(3000, () => console.log("meow, the server is on"))
})